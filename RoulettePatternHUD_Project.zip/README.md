# Roulette Pattern HUD

A dark HUD-style Android app inspired by the supplied reference image.

Included:
- Roulette history
- Red/black/zero classification
- Statistical pattern display
- Next expected colour indicator based on entered history
- Pattern analysis cards
- 0–36 number keypad
- Portrait layout

Important: roulette outcomes are random. The "Next Expected" and percentages are historical/statistical indicators, not guaranteed predictions or a way to ensure profit.

## Build
Open this folder in Android Studio and run:
`Build > Build APK(s)`

The project uses Android Gradle Plugin 8.13.0 and compileSdk 35.
