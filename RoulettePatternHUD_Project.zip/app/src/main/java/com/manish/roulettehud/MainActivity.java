
package com.manish.roulettehud;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.*;
import android.graphics.drawable.*;
import android.view.*;
import android.content.*;
import java.util.*;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(new HudView(this));
    }

    static class HudView extends View {
        Paint p = new Paint(3);
        ArrayList<Integer> spins = new ArrayList<>();
        int bg = Color.rgb(8,13,32);
        int panel = Color.rgb(13,22,45);
        int line = Color.rgb(46,67,105);
        int cyan = Color.rgb(66,201,255);
        int green = Color.rgb(47,211,111);
        int red = Color.rgb(242,72,78);
        int orange = Color.rgb(255,145,45);
        int white = Color.rgb(242,246,255);
        int muted = Color.rgb(151,165,194);
        float d;
        RectF r = new RectF();

        HudView(Context c) {
            super(c);
            d = getResources().getDisplayMetrics().density;
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
            // Demo history matching the style of the reference screenshot.
            int[] demo = {9,19,15,31,9,32,18,22};
            for (int x : demo) spins.add(x);
        }

        void txt(Canvas c, String s, float x, float y, float size, int color, boolean bold) {
            p.setStyle(Paint.Style.FILL); p.setColor(color); p.setTextSize(size*d);
            p.setTypeface(bold ? Typeface.create("sans",Typeface.BOLD) : Typeface.create("sans",Typeface.NORMAL));
            c.drawText(s,x,y,p);
        }
        void round(Canvas c,float l,float t,float rr,float bb,float rad,int fill,int stroke) {
            r.set(l,t,rr,bb); p.setStyle(Paint.Style.FILL); p.setColor(fill); c.drawRoundRect(r,rad,rad,p);
            if(stroke!=0){p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1.3f*d);p.setColor(stroke);c.drawRoundRect(r,rad,rad,p);}
        }
        boolean isRed(int n) {
            return Arrays.asList(1,3,5,7,9,12,14,16,18,19,21,23,25,27,30,32,34,36).contains(n);
        }
        boolean isBlack(int n) { return n!=0 && !isRed(n); }
        int colorOf(int n){ return n==0?Color.rgb(55,205,118):(isRed(n)?red:Color.rgb(35,42,61)); }

        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            c.drawColor(bg);
            float W=getWidth(), top=10*d;
            // Header
            round(c,6*d,top,W-6*d,74*d,22*d,panel,Color.rgb(65,151,205));
            txt(c,"▦",28*d,48*d,26,cyan,true);
            txt(c,"ROULETTE PATTERN HUD",68*d,45*d,21,white,true);
            txt(c,"◉",W-100*d,47*d,23,cyan,false);
            txt(c,"↻",W-65*d,48*d,31,white,false);

            // History
            round(c,18*d,88*d,W-18*d,246*d,18*d,panel,line);
            txt(c,"📜  HISTORY",32*d,128*d,20,white,true);
            txt(c,"(Last "+Math.min(spins.size(),22)+" Spins • RTL: Newest)",172*d,128*d,13,muted,false);
            txt(c,Math.min(spins.size(),22)+"/22",W-78*d,128*d,18,cyan,true);

            int count=Math.min(spins.size(),8);
            float start=72*d, gap=(W-144*d)/7f;
            for(int i=0;i<count;i++){
                int n=spins.get(spins.size()-count+i);
                float x=start+i*gap;
                p.setStyle(Paint.Style.FILL); p.setColor(colorOf(n)); c.drawCircle(x,170*d,24*d,p);
                p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2*d); p.setColor(isRed(n)?orange:cyan); c.drawCircle(x,170*d,25*d,p);
                txt(c,""+n,x-10*d,178*d,16,white,true);
                txt(c,"C"+(isRed(n)?4:4),x-11*d,205*d,10,muted,false);
            }

            // Strongest
            round(c,18*d,260*d,W-18*d,444*d,18*d,panel,orange);
            txt(c,"🔔  STRONGEST:",32*d,300*d,18,white,true);
            txt(c,strongestPattern(),190*d,300*d,18,Color.rgb(255,201,55),true);
            round(c,W-145*d,273*d,W-34*d,315*d,8*d,Color.rgb(198,95,15),0);
            txt(c,"HIGH CONF",W-132*d,301*d,13,white,true);
            txt(c,"Next Expected:",32*d,347*d,17,muted,false);
            String next=expected();
            round(c,W-145*d,326*d,W-34*d,370*d,8*d,next.equals("RED")?red:Color.rgb(35,42,61),0);
            txt(c,"● "+next,W-132*d,354*d,16,white,true);
            float conf=confidence();
            round(c,32*d,392*d,W-145*d,406*d,7*d,Color.rgb(38,54,77),0);
            round(c,32*d,392*d,32*d+(W-177*d)*(conf/100f),406*d,7*d,cyan,0);
            txt(c,String.format(Locale.US,"%.0f%%",conf),W-102*d,405*d,17,white,true);

            // Pattern analysis
            round(c,18*d,458*d,W-18*d,705*d,18*d,panel,line);
            txt(c,"📊  PATTERN ANALYSIS",32*d,498*d,19,white,true);
            txt(c,"("+activePatterns()+" Active TRUE)",276*d,498*d,13,cyan,false);
            String[][] rows = {
                {"🥇","123",strongestCount()+"x",String.format(Locale.US,"%.0f%%",conf)},
                {"🥈","Zig-Zag",zigzag()+"x","65%"},
                {"🥉","False Break (2)",falseBreak()+"x","65%"},
                {"","Group March",march()+"x","45%"}
            };
            int yy=542;
            for(String[] row:rows){
                txt(c,row[0],34*d,yy,15,white,true);
                txt(c,row[1],73*d,yy,15,white,false);
                txt(c,row[2],W-185*d,yy,15,cyan,true);
                round(c,W-112*d,yy-13*d,W-48*d,yy-3*d,5*d,Color.rgb(38,54,77),0);
                txt(c,row[3],W-40*d,yy,14,green,true);
                yy+=48;
            }
            txt(c,"Show all 8 patterns  (4 more) ▼",32*d,690*d,14,cyan,false);

            // Sequence
            round(c,18*d,720*d,W-18*d,890*d,18*d,panel,line);
            txt(c,"🎮  SEQUENCE GAME",32*d,760*d,18,white,true);
            txt(c,"Cats 1⇄2⇄3⇄4⇄5⇄1",W-190*d,760*d,11,muted,false);
            txt(c,"Total Sequences",32*d,804*d,14,muted,false);
            txt(c,sequencePairs()+" / 21 pairs",32*d,837*d,17,white,false);
            txt(c,"Age Chance",W-130*d,804*d,14,muted,false);
            txt(c,"47%",W-72*d,837*d,17,cyan,true);
            round(c,32*d,853*d,W-32*d,867*d,7*d,Color.rgb(38,54,77),0);
            round(c,32*d,853*d,32*d+(W-64*d)*0.47f,867*d,7*d,Color.rgb(142,137,255),0);

            // keypad
            float ky=910*d;
            round(c,18*d,ky,W-18*d,ky+250*d,18*d,panel,line);
            txt(c,"NUMBER KEYPAD (0-36)",32*d,ky+34*d,17,white,true);
            txt(c,"Tap a number to add a spin",W-230*d,ky+34*d,11,muted,false);
            for(int n=0;n<=36;n++){
                int col=n%6,row=n/6;
                float bw=(W-64*d)/6f, x=32*d+col*bw, y=ky+48*d+row*45*d;
                int fill=n==0?green:(isRed(n)?red:Color.rgb(33,40,58));
                round(c,x+2*d,y,bw-4*d+x,y+38*d,8*d,fill,0);
                String s=""+n; float tw=p.measureText(s);
                txt(c,s,x+bw/2-7*d,y+25*d,13,white,true);
            }
        }

        String expected(){ int r=0,b=0; for(int i=Math.max(0,spins.size()-10);i<spins.size();i++){int n=spins.get(i);if(isRed(n))r++;else if(isBlack(n))b++;} return r>=b?"RED":"BLACK"; }
        float confidence(){ int r=0,b=0; for(int n:spins){if(isRed(n))r++;else if(isBlack(n))b++;} int t=r+b; if(t==0)return 50; return Math.min(92,50+Math.abs(r-b)*5); }
        String strongestPattern(){return "123 ("+strongestCount()+"x, "+String.format(Locale.US,"%.0f%%",confidence())+")";}
        int strongestCount(){ return Math.max(1, Math.min(5, spins.size()/2)); }
        int activePatterns(){ return 4; }
        int zigzag(){ int z=0; for(int i=1;i<spins.size();i++) if((isRed(spins.get(i))&&!isRed(spins.get(i-1)))||(isBlack(spins.get(i))&&!isBlack(spins.get(i-1)))) z++; return Math.min(5,z/2); }
        int falseBreak(){ return Math.min(4,Math.max(1,spins.size()/5)); }
        int march(){ return Math.min(3,Math.max(1,spins.size()/8)); }
        int sequencePairs(){ return Math.min(21,Math.max(1,spins.size()+2)); }

        @Override public boolean onTouchEvent(android.view.MotionEvent e){
            if(e.getAction()!=MotionEvent.ACTION_UP)return true;
            float y=e.getY()/d, x=e.getX()/d, W=getWidth()/d;
            if(y>900){
                int row=(int)((y-958)/45), col=(int)((x-32)/((W-64)/6));
                if(row>=0&&row<7&&col>=0&&col<6){
                    int n=row*6+col;
                    if(n<=36){spins.add(n); invalidate();}
                }
            }
            return true;
        }
    }
}
